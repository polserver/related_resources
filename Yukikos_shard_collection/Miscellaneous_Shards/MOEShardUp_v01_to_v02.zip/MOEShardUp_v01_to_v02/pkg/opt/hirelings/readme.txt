Name hirelings
Version 0.1
Requires gumps 2.1
Requires raceclasssys 0.1
Requires conjuration 0.1
Requires resnpc 0.1
Maintainer M.o.E
Email m.o.e@moe99.cjb.net

These sripts are published without any warranty, they are not completely tested so there could (will)
be some bugs in them. If you find a bug, fix it and send the fix to me, please. If you can't fix the
bug send it to me (m.o.e@moe99.cjb.net) with exact desciptions of the bug and how to reproduce it
(with example code). If my time permits, I'll then try to fix it.

Intro:
The hirelings package gives the character the possibility to hire NPCs on the shard for a spezific
amount of money (for a week, depending on the skills they have) and make them work for the char.

Now the hired NPC will act like a tamed animal with some additional possibilities:
The NPC can work for you (mining, luberjacking,...) if the NPC has the skills to do that.

Command list for hired NPCs:
Standard:
kill,attack,fight
stop
come
follow
transfer
release
guard
fetch
drop
speak

Extra:
mount,ride:     Mount a horse, ostard,...
dismount:       Dismount a horse, ...
work:           Get the Stats and Skills of the NPC and let it work for you.
remove items:   Removes all items from the NPC backpack.
wear:           Equip a weapon or armor.
undress:        Undress all equipt items from NPC
camp:           Guards the area where it stands.
help:           Search for enemies.
heal,cure:      Heal or cure someone (with bandages or spells -> if healernpc)
resurrect me:   Resurrects master if it is a healernpc
quote:          Give the NPC a quote it should say to other PCs when you are offline.
training:       Learn from an merchant NPC (says: vendor train)
training <skillname>: Learn from an merchant NPC (says: vendor train <skillname>)
pay <amount>:   Pay merchant NPC for what your NPC have learned (gives <amount> of gold to the
                merchant NPC, if it is in the backpack of your NPC.
move:           Moves a little away from you (e.g. if you are blocked)
throw:          Throws exlosion potion to opponent if there is one in the backpack of your NPC.
loot:           Loot corpse near the NPC.
autoloot:       Autoloot corpse the NPC has killed (e.g. during the camp mode)
carve:          Carve corpse near NPC.
wash:           Wash the bloody bandages in the NPC backpack.
help:           Search and fight enemy.
brb:            Clear event queue
stuck:          Try to free a stuck NPC

You have to pay more money to your NPC to make them stay with you more time.
And you can train them on dummies...

Files in the package:
pkg.cfg (pkg/opt/hirelings): Package config file.

ctrl_reg.src (pkg/opt/hirelings): Script to register this package with the control package.

npcskillwin.src (scripts/misc): Gump which shows the stats and skills of the NPC and where you
can select the skill you want the NPC to work for you.

hirefkts.inc (pkg/opt/hirelings): Some common functions.

selection.src (pkg/opt/hirelings): A workbook to select a work if a skill have more than one
possibility (e.g. Mining: smelting, mining, stonemiming).

npcskill.cfg (pkg/opt/hirelings): Definition of the skills which has more than one posibility.

Description:
npcskill 45                           // skill id
{
  Name      mining                    // name of the skill
  select    smelting                  // first selection
  select    mining                    // second selection
  select    stonemining               // third selection
  script    :npcmining:smelting       // first script ( corresponds to the first selection)
  script    :npcmining:mining         // second script
  script    :npcmining:stonemining    // third script
}

hired.src (pkg/opt/hirelings): NPC AI for the hired NPC.

supportpc.inc (scripts/include): Needed by hired.src.

creaturefkts.inc (scripts/include): Needed by supportpc.inc.

commonfkts.inc (scripts/include): Needed by creaturefkts.inc.

npctrain.inc (scripts/include): Needed by creaturefkts.inc to train NPCs on dummys and archery butt.

npcalchemie, ...  (pkg/opt/hirelings): The skill pkgs for NPCs. Activate or deactivate the pkgs you
use or do not use for your PCs. (e.g. if you use the blacksmithy pkg on you shard for blacksmithing
activate the npcblacksmithy pkg and deactivate the npccrafting pkg)

From other pkgs:
karmafame.inc (scripts/include): Needed by creaturefkts.inc. My Karma/Fame-System to check if the
near NPCs are bad or good.

resnpc.inc (scripts/include): Needed by supportpc.inc to create the rune of memory in the NPC
backpack for possible later resurrection. (see my resnpc package)

Feedback:

If you have questions or bugfixes, please send them to m.o.e@moe99.cjb.net
Also positiv feedback are welcome.

