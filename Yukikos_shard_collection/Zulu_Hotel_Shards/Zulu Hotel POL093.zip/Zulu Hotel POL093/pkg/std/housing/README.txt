*** NOTE ***

You will not be able to use the 7 New Housetypes until:

a. OSI patches everybody's multi.mul and multidx.mul
b. You (and any users) download those files from ftp://ftp.owo.com/pub/uo/houses


Door 0x067B
{
    xmod    +1
    ymod    -1
    script  door
    doortype metal
}

Door 0x06ab
{
    xmod +1
    ymod -1
    script door
    doortype wood
}
