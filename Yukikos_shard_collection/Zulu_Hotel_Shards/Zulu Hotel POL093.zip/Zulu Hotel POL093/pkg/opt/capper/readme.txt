Capper
by zulu (zuluhotel@hotmail.com)

This is designed to replace all the other cap programs you have.

You can set the following:
set  STATCAP to a number
set SKILLCAP to a number

If each stat is higher than that number, it will lower it to that number.
A setting of 100, will check each stat and if they are over 100,
it will set it to 100. (that would be 100 in each stat)

With the other stat package: if you set a max of 300, it would not
adjust all the stats equally if they were over 300.

If any Skill is over the number, then it will lower it to that number.
A setting of 110, will check each skill and if they are over 110,
it will set it to 110. (that would be 110 in each skill)

**********
INSTALLING
**********

unzip to the following directory  \pol\pkg\opt\capper

My code is based on other people's work:
Syzygy's (syzygy@pobox.com) code and Svovl's (cnk@mail1.stofanet.dk) code.
