Magic Wands - ver .4 updated Feb 2, 2000
****************************************
Zulu (zuluhotel@hotmail.com)

added a delay in casting of scrolls.
added some new animation.
added 64 magic wands with charges.
added a delay in casting of wands.
magic wands are destroyed when charges = 0

players need to use item id to find out what kind
of wand and how many charges there are left.

unzip the files into the \pol\pkg\opt\zulumagic


This package will replace the standard magic package. You will need to disable the package in \pol\pkg\std\magic
