README.TXT For POL094 - u.src

Installation:
Unzip into POL094 root dir.
I believe this script requires POL094.

Contact:
E-mail: mistercharmer@hotmail.com
Or catch me on the forum --> http://pol.verysurf.de/

