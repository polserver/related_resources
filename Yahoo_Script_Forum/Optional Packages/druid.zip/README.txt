Installation.
-------------

1. extract to pkg\skills\
2. append the inscription.src to yours (the ones commented for druid)


Info.
-----

There is total of 11 spells, id suggest going trough them all and figure good reg usage i never did :)
the earthen staff is needed to cast them.


Lucious 6/24/03
gm_lucious@leavarius.com
icq: 17702919

I have used many of other peoples scripts as template and alas i cant remember which ones anymore
but nevertheless credits for you all.