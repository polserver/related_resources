Datafile.inc
Austin Heilman
http://www.tsse.net

This is an include designed to make the use of datafiles
significantly easier and less redundant.

To install, place in pol/scripts/include/
This requires atleast pol 092 as this is the core where
access to datafile.em first became available.

