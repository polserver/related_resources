Traveler AI 0.1

Instructions
============

Copy traveling.cfg to /config and append npcdesc.cfg info in /config/npcdes.cfg
Move traveler AI to /scrits/AI

How Does it Work?
=================

  Just say "travel" to the npc and he will open a menu(it looks into traveling.cfg) to you choose where you would like to go.
  
How to Add New Locations?
=========================

  Just Edit traveling.cfg, add another location there, and the script will do the rest :) (just restart the server)

ToDo
====

  Make a Nicer menu and better the AI

Charles Haustron