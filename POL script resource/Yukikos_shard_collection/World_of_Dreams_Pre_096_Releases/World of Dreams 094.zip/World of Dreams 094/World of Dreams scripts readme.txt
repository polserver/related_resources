For information regarding the installation of these scripts and changes that have been made, see http://www.drocket.net/

Also visit the WoD website at http://www.theworldofdreams.com/
