This package contains scripts and functions related to skill advancement.

Experienced-based advancement:
Assorted actions can award experience points towards a specific skill (using the
function AwardSkillExperience in skill_advancement.inc.)  After a certain amount of
experience is gained, the player's skill advanced (in 0.1 increments.)  This skill is
applied to the player's Temporary Attribute Mod for that skill (as opposed to the player's
base skill, which is only used for trained skill.)

There are 2 CProps that are placed on the player related to this advancement:

skill_advancement_experience
This CProp is a dictionary, and the keys to the dictionary are the attributeIDs of the
assorted skills that have gained experience.  When a new level breakpoint is reached,
the experience needed to gain that level is subtracted from the amount of experience
that the player has, and the new level in that experience is recorded in...

skill_advancement_levels
This CProp is also a dictionary with its keys being the attributeIDs of skills that
have gained a level.

