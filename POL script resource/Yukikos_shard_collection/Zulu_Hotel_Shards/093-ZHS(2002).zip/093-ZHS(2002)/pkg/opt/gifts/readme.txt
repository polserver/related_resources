Gift Package 1
version 1.2
By BlahGoD
blahgod@thehellclan.com

extract all files to pol/pkg/items/gifts/

!!!except for:

useDyes.src -  replace the useDyes.src in your tailoring package ... needed for furn dye tub

etherealmountsV1.zip  -  read the files in the zip, optional package

The following are included in this package:

Etheral Mounts - Vet awards...still beta, please please please tell me if you find any bugs with this besides the mounts not being clear :-p

Bless Deed - so far so good with these, will not allow use on players, already newbied stuff, and containers (anything with a MaxItems property)

Furniture Dye Tub - sorry for the odd graphic, works well though

Valentine Card - creates a message that says "Happy Valentine's Day!  - Shard Staff" and places a bag of conversation candys in the players pack

Monster Statue Deed - creates a random monster statue in players pack, sound effects play on double click

Firework wand - basic fireworks, doesnt have charges yet

Snowglobe Deed - creates a crystal ball dyed ice color with the message "a snowy scene of (random town name)"

Pile of snow - works well, and lets those who dont have it join in the fun too, cleans up after itself as well, still need to add in snowball effect, planning on using magic arrow as soon as i can change color of animation.