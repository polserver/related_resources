package pol;

/**
 * Insert the type's description here.
 * Creation date: (12/03/2001 16:20:07)
 * @author: Lapo Luchini <lapo@lapo.it>
 */
public final class VarArray extends Variable {
	private java.util.Vector value;
/**
 * VarString constructor comment.
 */
public VarArray() {
	this.value=new java.util.Vector();
}
/**
 * VarString constructor comment.
 */
public VarArray(int initialCapacity) {
	this.value=new java.util.Vector(initialCapacity);
}
/**
 * getPOLformat method comment.
 */
public String getPOLformat() {
	StringBuffer u=new StringBuffer();
	u.append('a');
	u.append(value.size());
	u.append(':');
	for(java.util.Enumeration e=value.elements(); e.hasMoreElements(); )
		u.append((Variable)e.nextElement());
	return(u.toString());
}
/**
 * Insert the method's description here.
 * Creation date: (13/03/2001 18:57:58)
 * @param index int
 * @param value pol.Variable
 */
public int getSize() {
	return(this.value.size());
}
/**
 * Insert the method's description here.
 * Creation date: (13/03/2001 18:57:58)
 * @param index int
 * @param value pol.Variable
 */
public Variable getValue(int index) {
	return((Variable)this.value.get(index-1));
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 15:53:57)
 * @return pol.Variable
 * @param s java.lang.String
 */
public static Variable parsePOLformat(ParserState ps) {
	if(ps.str[ps.pos++]!='a')
		throw new POLParserException(ps, "POL's array values must begin with 'a'");
	int len=0;
	while(Character.isDigit(ps.str[ps.pos]))
		len=len*10+Character.getNumericValue(ps.str[ps.pos++]);
	if(ps.str[ps.pos]!=':')
		throw new POLParserException(ps, "POL's string values must have a ':'");
	else
		ps.pos++;
	VarArray u=new VarArray(len);
	for(int i=1; i<=len; i++)
		u.setValue(i, Variable.parsePOLformatGeneric(ps));
	return(u);
}
/**
 * Insert the method's description here.
 * Creation date: (13/03/2001 18:57:58)
 * @param index int
 * @param value pol.Variable
 */
public void setValue(int index, Variable value) {
	if(index>this.value.size())
		this.value.setSize(index);
	this.value.setElementAt(value, index-1);
}
}
