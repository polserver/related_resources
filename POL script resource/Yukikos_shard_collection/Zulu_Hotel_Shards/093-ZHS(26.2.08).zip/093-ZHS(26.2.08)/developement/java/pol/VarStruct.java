package pol;

/**
 * Insert the type's description here.
 * Creation date: (12/03/2001 16:21:05)
 * @author: Lapo Luchini <lapo@lapo.it>
 */
public final class VarStruct extends Variable {
/**
 * getPOLformat method comment.
 */
public String getPOLformat() {
	return null;
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 15:53:57)
 * @return pol.Variable
 * @param s java.lang.String
 */
public static Variable parsePOLformat(ParserState ps) {
	throw new POLParserException(ps, "these are not parsable yet");
}
}
