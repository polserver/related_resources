Blackthornes Revenge Addon:
---------------------------

This is just a small package that contains items of the new blackthornes  revenge expansion!
to fully enjoy the new items you should either:

(verified way): 
- install blackthornes revenge 3d (i know 3d sucks but in 2d you will only 
					see the normal item gfx)
or (unverified way):
- install third dawn and patch up to the latest patch.

either way:
- get uorice to remove your client encryption and you will be able to connect with the newest client.


installing the package:
- install a pol emulator (pol92 e.g.)
- extract that package to /pkg/opt/btritems

boot up your pol and login with the uorice generated client

small comment:
i know this package is nothing really good or even real code but it took me
more than 2 hours to just write all new items into that cfg and that was a plain
boring work!
if you think this package is a waste of space just delete it :P

some of the new items:

- 2 handed really big sword (demon sword)
- monster weapons (liche staff and so on)
- samurai and ninja gear... 
- some nice mage clothes (arcane clothing)
- other new weapons (6 new sword gfx and so on...)

if anyone is in the mood to expand this package (e.g. with a monster package)
or just want to share experience with 3rd dawn drop me a mail

che666@uni.de

p.s. this is just a very small contribution for all the nice things i already 
got from the scriptforum. theres more to come when i have more done on my own.
