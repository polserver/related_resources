TUS Conversion Information

If you have a TUS shard that you wish to convert to POL, please see http://www.dogbox.com.au/tus2pol/#
