package pol;

/**
 * Insert the type's description here.
 * Creation date: (12/03/2001 16:19:38)
 * @author: Lapo Luchini <lapo@lapo.it>
 */
public final class VarReal extends Variable {
	private double value;
/**
 * VarReal constructor comment.
 */
public VarReal(double value) {
	this.value=value;
}
/**
 * getPOLformat method comment.
 */
public String getPOLformat() {
	return("r"+value);
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 16:21:38)
 * @return double
 */
public double getValue() {
	return value;
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 15:53:57)
 * @return pol.Variable
 * @param s java.lang.String
 */
public static Variable parsePOLformat(ParserState ps) {
	throw new POLParserException(ps, "these are not parsable yet");
}
/**
 * Insert the method's description here.
 * Creation date: (12/03/2001 16:21:38)
 * @param newValue double
 */
public void setValue(double newValue) {
	value = newValue;
}
}
