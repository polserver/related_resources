
The files in this directory are client files have not been patched in a 
fashion that breaks POL.

If you are unable to create a character, it is likely because your prof.txt
file has been patched to the most recent version, in which starting characters
get 80 points rather than the 65 POL expects them to have. Use this prof.txt
instead and you should be able to create a character.
Note that this needs to be used on the CLIENT machine, not the SERVER machine.

If you are not seeing the leggings of your armor, it is because your art.mul
file has been modified to put that on a new layer. This allows you to wear
your armor leggings over your pants, which is a welcome change- however, POL
doesn't know about the new layer yet. To fix this, I believe you need to get 
an older art.mul. This file it too large to be distributed with every POL
download, though, so you'll have to ask around to get one.


Madman Across the Water
