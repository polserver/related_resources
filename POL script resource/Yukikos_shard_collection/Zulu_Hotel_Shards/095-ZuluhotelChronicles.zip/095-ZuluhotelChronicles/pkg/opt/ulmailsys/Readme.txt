TODO: 
`Double click to read the message.
`Use datafiles instead of creating accounts.
`Finish it, probably wont. Lost cause.