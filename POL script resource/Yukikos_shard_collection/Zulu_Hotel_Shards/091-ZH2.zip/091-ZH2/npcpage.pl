
open (NPCS, "<config/npcdesc.cfg") or die ("Cannot find NPC file.");

my %temphash, @npclist;
my @skillsarray = ("magery",
                   "inscription",
                   "wrestling",
                   "tactics",
                   "meditation",
                   "animallore",
                   "animaltaming",
                   "veterinary",
                   "macefighting",
                   "magicresistance",
                   "alchemy",
                   "anatomy",
                   "itemid",
                   "armslore",
                   "parry",
                   "begging",
                   "blacksmithy",
                   "bowcraft",
                   "peacemaking",
                   "camping",
                   "cartography",
                   "cooking",
                   "detectinghidden",
                   "enticement",
                   "evaluatingintelligence",
                   "healing",
                   "fishing",
                   "herding",
                   "hiding",
                   "provocation",
                   "lockpicking",
                   "snooping",
                   "musicianship",
                   "archery",
                   "spiritspeak",
                   "stealing",
                   "tailoring",
                   "tasteidentification",
                   "tracking",
                   "swordsmanship",
                   "fencing",
                   "lumberjacking",
                   "mining",
                   "stealth",
                   "removetrap",
                   "poisoning",
                   "carpentry",
                   "tinkering",
                   "forensicevaluation");

@skillsarray = sort @skillsarray;

# open (OUTPUTTEST, ">outputtest.txt");

while (chomp($tempvar = <NPCS>))
{
     if ($tempvar =~ /(^\s*\n)|(\{)|(\bspell\b)|(^\s*\/)/) {next;}
     
     if ($tempvar =~ /cprop/i)
     {
          $tempvar =~ s/^\s*cprop//i;
          if (!($tempvar =~ /(guardsignore)|(nocorpse)|(noloot)|(undead)/i)) {next;}
     
     }
     
     if ($tempvar =~ /\}/)  {
         unshift (@npclist, {});
         %{$npclist[0]} = %temphash;
  #       my $f = shift @npclist; 
  #       warn "$f"; 
  #       warn "1) $f->{'objtype'} 2) $npclist[0]->{'objtype'} 3) $temphash{'objtype'}";        
         undef %temphash;
         next;
     }
     
#     print OUTPUTTEST keys %temphash;
#     print OUTPUTTEST "\n";
#     print OUTPUTTEST values %temphash;
#     print OUTPUTTEST "\n";
     $keyword = "";
#     ($keyword, $tempvar) = split / /, $tempvar, 2;
     $tempvar =~ s/^\s*(\w*)//;
     $keyword = $1;
     $keyword = lc($keyword);
     $tempvar =~ s/^\s*//;
     $temphash{$keyword} = lc($tempvar);
 #    print OUTPUTTEST "$keyword";

}

close NPCS;

open (NPCPAGE, ">monstertemplate.html") or die ("Unable to create monstertemplate.html");

print NPCPAGE <<EOF;

<html>
<head>
<title>Tapestry of Ages NPC Templates</title>
<style type="text/css">
<!--

body {font-size : small}
th {background-color : ff9900; color : 000000; font-size:small}
td {font-size:small}

-->
</style>
</head>
<body bgcolor=black text="#FF9900" link="#FFFFFF" vlink="#AAAAAA">

<p>A few notes. An NPC with script "merchant" or "animaltrainer"
 will train in any skills he has, to 
a maximum level of one third of his skill. <br>
Flags key:
<ul>
<li>i : Guardsignore. Amazingly enough, means that the guards will ignore.</li>
<li>I : Invulnerable. Cannot take damage.</li>
<li>g : Good.</li>
<li>e : Evil.</li>
<li>n : Neutral.</li>
<li>c : Leaves no corpse.</li>
<li>u : Undead.</li>
</ul>
AS is attack skill: W-wrestling S-swords F-fencing M-macefighting.<br>
Lootgroup gives the number of the loot from the config files, and then the chance of
magic items after a slash if defined.<br>
The ObjType column gives the ObjType, then the color.</p>

<p>Skip to: <a href="#town">Townsfolk</a> | <a href="#human">Humans</a> | 
<a href="#animal">Animals</a> | <a href="#monster">Monsters</a>
| <a href="#extra">Extraplanar</a> | <a href="#other">Other</a></p>

<table cellpadding=1 cellspacing=2 border=1>

EOF

my @npcperson;
my @npcanimal;
my @npcmonster;
my @npcextraplanar;
my @npcother;
my @npcevilperson;

#@keylist = keys %{$npclist[0]};
#print "keytest1 - @keylist\n";

#print " @npclist VTest - $npclist[0]->{'objtype'}\n";

while ($yo = shift @npclist)
{
 #   print "YO: $yo->{'objtype'}";
    
    if (${$yo}{'npctemplate'} =~ /(vortex)|(bladespirit)|(bewitched)/i)
    {
        $npcother[$#npcother+1] = $yo;
        next;
    }    
    
    if (${$yo}{'objtype'} =~ /0x190/i)
    {
        $npcperson[$#npcperson+1] = $yo;
        next;
    }
    
    if (${$yo}{'script'} =~ /(animal)|(dumbkillpcs)|(barker)|(wolf)|(chicken)|(cat)|(sheep)/i)
    {
        $npcanimal[$#npcanimal+1] = $yo;
        next;
    }
    
    if (${$yo}{'npctemplate'} =~ /(daemon)|(elemental)|(djinn)|(icefiend)/i)
    {
        $npcextraplanar[$#npcextraplanar+1] = $yo;
        next;
    }
    
    $npcmonster[$#npcmonster+1] = $yo;
    
}

@npcmonster = sort { $a->{'npctemplate'} cmp $b->{'npctemplate'} } @npcmonster;
@npcother = sort { $a->{'npctemplate'} cmp $b->{'npctemplate'} } @npcother;
@npcextraplanar = sort { $a->{'npctemplate'} cmp $b->{'npctemplate'} } @npcextraplanar;
@npcanimal = sort { $a->{'npctemplate'} cmp $b->{'npctemplate'} } @npcanimal;
@npcperson = sort { $a->{'npctemplate'} cmp $b->{'npctemplate'} } @npcperson;

print NPCPAGE <<EOF;

<tr>
<td colspan=14 align=center style="font-size : medium; font-weight: bold"><a name="town">Townsfolk</a></td></tr>
<tr><th align=center>Template</th>
<th align=center>Script</th>
<th align=center>ObjType</th>
<th align=center>STR</th>
<th align=center>DEX</th>
<th align=center>INT</th>
<th align=center>Flags</th>
<th align=center>Speech</th>
<th align=center>Skills</th>
<th align=center>AS</th>
<th align=center>Atk Spd</th>
<th align=center>Dmg</th>
<th align=center>AR</th></tr>

EOF

while ($currententry = shift @npcperson)
{
    if ((${$currententry}{'alignment'} =~ /evil/) or (${$currententry}{'script'} =~ /doppelganger/))
    {
         $npcevilperson[$#npcevilperson+1] = $currententry;
         next;
    }
        
    print NPCPAGE "<tr><td valign=top align=left>${$currententry}{'npctemplate'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'script'}</td>\n";
    print NPCPAGE "<td valign=top align=center>${$currententry}{'objtype'}<br>${$currententry}{'color'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'str'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'dex'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'int'}</td>\n";
    
    my $flags="";
    if (${$currententry}{'settings'} =~ /invul/i) {$flags .= "I";}
    if (${$currententry}{'guardignore'} =~ /1/i) {$flags .= "i";}
    if (${$currententry}{'alignment'} =~ /evil/i) {$flags .= "e";}
    if (${$currententry}{'alignment'} =~ /good/i) {$flags .= "g";}
    if (${$currententry}{'alignment'} =~ /neutral/i) {$flags .= "n";}
    if (${$currententry}{'guardkill'} or ${$currententry}{'nocorpse'}) {$flags .= "c";}
    if (${$currententry}{'undead'}) {$flags .= "u";}
    
    if (!$flags) {$flags='&nbsp;';}
    print NPCPAGE "<td valign=top align=left>$flags</td>\n";
    
    if (!${$currententry}{'speech'}) {${$currententry}{'speech'} = '&nbsp;';}
    print NPCPAGE "<td valign=top align=center>${$currententry}{'speech'}</td>\n";
    
    $skills="";
    foreach $skill (@skillsarray)
    {
        if (${$currententry}{$skill})
        {
            if ($skills) {$skills .= "<br>";}
            $skillid = $skill;
            $skill =~ s/identification/id/;
            $skill =~ s/evaluatingintelligence/evalint/;
            $skill =~ s/forensicevaluation/forensic/;
            $skill =~ s/magicresistance/resist/;
            $skill =~ s/detectinghidden/detecthidden/;
            $skills .= "$skill ${$currententry}{$skillid}";
        }
    }
    
    if (!$skills) {$skills = '&nbsp;';}
    print NPCPAGE "<td valign=top align=left>$skills</td>\n";
    
    ${$currententry}{'attackskillid'} =~ s/^\s*//;
    @AS = split //, ${$currententry}{'attackskillid'};
    $AS[0]= uc($AS[0]);
    print NPCPAGE "<td valign=top align=left>$AS[0]</td>\n";
    
    print NPCPAGE "<td valign=top align=center>${$currententry}{'attackspeed'}</td>\n";
    
    print NPCPAGE "<td valign=top align=center>${$currententry}{'attackdamage'}</td>\n";
    
    if (!(${$currententry}{'ar'})) {${$currententry}{'ar'} = '&nbsp;';}
    print NPCPAGE "<td valign=top align=center>${$currententry}{'ar'}</td></tr>\n\n";
}

print NPCPAGE <<EOF;

<tr>
<td colspan=14 align=center style="font-size : medium; font-weight: bold"><a name="human">Humans</a></td></tr>
<tr><th align=center>Template</th>
<th align=center>Script</th>
<th align=center>ObjType</th>
<th align=center>STR</th>
<th align=center>DEX</th>
<th align=center>INT</th>
<th align=center>Flags</th>
<th align=center>Nature</th>
<th align=center>Skills</th>
<th align=center>AS</th>
<th align=center>Atk Spd</th>
<th align=center>Dmg</th>
<th align=center>AR</th></tr>

EOF

while ($currententry = shift @npcevilperson)
{
    
    print NPCPAGE "<tr><td valign=top align=left>${$currententry}{'npctemplate'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'script'}</td>\n";
    print NPCPAGE "<td valign=top align=center>${$currententry}{'objtype'}<br>${$currententry}{'color'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'str'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'dex'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'int'}</td>\n";
    
    my $flags="";
    if (${$currententry}{'settings'} =~ /invul/i) {$flags .= "I";}
    if (${$currententry}{'guardignore'} =~ /1/i) {$flags .= "i";}
    if (${$currententry}{'alignment'} =~ /evil/i) {$flags .= "e";}
    if (${$currententry}{'alignment'} =~ /good/i) {$flags .= "g";}
    if (${$currententry}{'alignment'} =~ /neutral/i) {$flags .= "n";}
    if (${$currententry}{'guardkill'} or ${$currententry}{'nocorpse'}) {$flags .= "c";}
    if (${$currententry}{'undead'}) {$flags .= "u";}
    
    if (!$flags) {$flags='&nbsp;';}
    print NPCPAGE "<td valign=top align=left>$flags</td>\n";
    
    $nature = "";
    if (${$currententry}{'speech'}) {$nature .= "speech ${$currententry}{'speech'}";}
    if (${$currententry}{'provoke'}) 
    {
        if ($nature) {$nature .= "<br>";}
        $nature .= "prov ${$currententry}{'provoke'}";
    }
    
    if((${$currententry}{'lootgroup'}) or (${$currententry}{'magicitemchance'}))
    {
        if ($nature) {$nature .= "<br>";}
        $nature .= "lootgroup ${$currententry}{'lootgroup'}";
        if (${$currententry}{'magicitemchance'}) {$nature .= "/${$currententry}{'magicitemchance'}";}
    }
    
    if (${$currententry}{'tameskill'})
    {
        if ($nature) {$nature .= "<br>";}
        $nature .= "tameskill ${$currententry}{'tameskill'}";
    }
    
    if (!$nature) {$nature = '&nbsp;';}
    print NPCPAGE "<td valign=top align=center>$nature</td>\n";
    
    $skills="";
    foreach $skill (@skillsarray)
    {
        if (${$currententry}{$skill})
        {
            if ($skills) {$skills .= "<br>";}
            $skillid = $skill;
            $skill =~ s/identification/id/;
            $skill =~ s/evaluatingintelligence/evalint/;
            $skill =~ s/forensicevaluation/forensic/;
            $skill =~ s/magicresistance/resist/;
            $skill =~ s/detectinghidden/detecthidden/;
            $skills .= "$skill ${$currententry}{$skillid}";
        }
    }
    
    if (!$skills) {$skills = '&nbsp;';}
    print NPCPAGE "<td valign=top align=left>$skills</td>\n";
    
    ${$currententry}{'attackskillid'} =~ s/^\s*//;
    @AS = split //, ${$currententry}{'attackskillid'};
    $AS[0]= uc($AS[0]);
    print NPCPAGE "<td valign=top align=left>$AS[0]</td>\n";
    
    print NPCPAGE "<td valign=top align=center>${$currententry}{'attackspeed'}</td>\n";
    
    print NPCPAGE "<td valign=top align=center>${$currententry}{'attackdamage'}</td>\n";
    
    if (!(${$currententry}{'ar'})) {${$currententry}{'ar'} = '&nbsp;';}
    print NPCPAGE "<td valign=top align=center>${$currententry}{'ar'}</td></tr>\n\n";
}


print NPCPAGE <<EOF;

<tr>
<td colspan=14 align=center style="font-size : medium; font-weight: bold"><a name="animal">Animals</a></td></tr>
<tr><th align=center>Template</th>
<th align=center>Script</th>
<th align=center>ObjType</th>
<th align=center>STR</th>
<th align=center>DEX</th>
<th align=center>INT</th>
<th align=center>Flags</th>
<th align=center>Nature</th>
<th align=center>Skills</th>
<th align=center>AS</th>
<th align=center>Atk Spd</th>
<th align=center>Dmg</th>
<th align=center>AR</th></tr>

EOF

while ($currententry = shift @npcanimal)
{
    
    print NPCPAGE "<tr><td valign=top align=left>${$currententry}{'npctemplate'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'script'}</td>\n";
    print NPCPAGE "<td valign=top align=center>${$currententry}{'objtype'}<br>${$currententry}{'color'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'str'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'dex'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'int'}</td>\n";
    
    my $flags="";
    if (${$currententry}{'settings'} =~ /invul/i) {$flags .= "I";}
    if (${$currententry}{'guardignore'} =~ /1/i) {$flags .= "i";}
    if (${$currententry}{'alignment'} =~ /evil/i) {$flags .= "e";}
    if (${$currententry}{'alignment'} =~ /good/i) {$flags .= "g";}
    if (${$currententry}{'alignment'} =~ /neutral/i) {$flags .= "n";}
    if (${$currententry}{'guardkill'} or ${$currententry}{'nocorpse'}) {$flags .= "c";}
    if (${$currententry}{'undead'}) {$flags .= "u";}
    
    if (!$flags) {$flags='&nbsp;';}
    print NPCPAGE "<td valign=top align=left>$flags</td>\n";
    
    $nature = "";
    if (${$currententry}{'speech'}) {$nature .= "speech ${$currententry}{'speech'}";}
    if (${$currententry}{'provoke'}) 
    {
        if ($nature) {$nature .= "<br>";}
        $nature .= "prov ${$currententry}{'provoke'}";
    }
    
    if((${$currententry}{'lootgroup'}) or (${$currententry}{'magicitemchance'}))
    {
        if ($nature) {$nature .= "<br>";}
        $nature .= "lootgroup ${$currententry}{'lootgroup'}";
        if (${$currententry}{'magicitemchance'}) {$nature .= "/${$currententry}{'magicitemchance'}";}
    }
    
    if (${$currententry}{'tameskill'})
    {
        if ($nature) {$nature .= "<br>";}
        $nature .= "tameskill ${$currententry}{'tameskill'}";
    }
    
    if (!$nature) {$nature = '&nbsp;';}
    print NPCPAGE "<td valign=top align=center>$nature</td>\n";
    
    $skills="";
    foreach $skill (@skillsarray)
    {
        if (${$currententry}{$skill})
        {
            if ($skills) {$skills .= "<br>";}
            $skillid = $skill;
            $skill =~ s/identification/id/;
            $skill =~ s/evaluatingintelligence/evalint/;
            $skill =~ s/forensicevaluation/forensic/;
            $skill =~ s/magicresistance/resist/;
            $skill =~ s/detectinghidden/detecthidden/;
            $skills .= "$skill ${$currententry}{$skillid}";
        }
    }
    
    if (!$skills) {$skills = '&nbsp;';}
    print NPCPAGE "<td valign=top align=left>$skills</td>\n";
    
    ${$currententry}{'attackskillid'} =~ s/^\s*//;
    @AS = split //, ${$currententry}{'attackskillid'};
    $AS[0]= uc($AS[0]);
    print NPCPAGE "<td valign=top align=left>$AS[0]</td>\n";
    
    print NPCPAGE "<td valign=top align=center>${$currententry}{'attackspeed'}</td>\n";
    
    print NPCPAGE "<td valign=top align=center>${$currententry}{'attackdamage'}</td>\n";
    
    if (!(${$currententry}{'ar'})) {${$currententry}{'ar'} = '&nbsp;';}
    print NPCPAGE "<td valign=top align=center>${$currententry}{'ar'}</td></tr>\n\n";
    
}


print NPCPAGE <<EOF;

<tr>
<td colspan=14 align=center style="font-size : medium; font-weight: bold"><a name="monster">Monsters</a></td></tr>
<tr><th align=center>Template</th>
<th align=center>Script</th>
<th align=center>ObjType</th>
<th align=center>STR</th>
<th align=center>DEX</th>
<th align=center>INT</th>
<th align=center>Flags</th>
<th align=center>Nature</th>
<th align=center>Skills</th>
<th align=center>AS</th>
<th align=center>Atk Spd</th>
<th align=center>Dmg</th>
<th align=center>AR</th></tr>

EOF

while ($currententry = shift @npcmonster)
{
    
    print NPCPAGE "<tr><td valign=top align=left>${$currententry}{'npctemplate'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'script'}</td>\n";
    print NPCPAGE "<td valign=top align=center>${$currententry}{'objtype'}<br>${$currententry}{'color'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'str'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'dex'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'int'}</td>\n";
    
    my $flags="";
    if (${$currententry}{'settings'} =~ /invul/i) {$flags .= "I";}
    if (${$currententry}{'guardignore'} =~ /1/i) {$flags .= "i";}
    if (${$currententry}{'alignment'} =~ /evil/i) {$flags .= "e";}
    if (${$currententry}{'alignment'} =~ /good/i) {$flags .= "g";}
    if (${$currententry}{'alignment'} =~ /neutral/i) {$flags .= "n";}
    if (${$currententry}{'guardkill'} or ${$currententry}{'nocorpse'}) {$flags .= "c";}
    if (${$currententry}{'undead'}) {$flags .= "u";}
    
    if (!$flags) {$flags='&nbsp;';}
    print NPCPAGE "<td valign=top align=left>$flags</td>\n";
    
    $nature = "";
    if (${$currententry}{'speech'}) {$nature .= "speech ${$currententry}{'speech'}";}
    if (${$currententry}{'provoke'}) 
    {
        if ($nature) {$nature .= "<br>";}
        $nature .= "prov ${$currententry}{'provoke'}";
    }
    
    if((${$currententry}{'lootgroup'}) or (${$currententry}{'magicitemchance'}))
    {
        if ($nature) {$nature .= "<br>";}
        $nature .= "lootgroup ${$currententry}{'lootgroup'}";
        if (${$currententry}{'magicitemchance'}) {$nature .= "/${$currententry}{'magicitemchance'}";}
    }
    
    if (${$currententry}{'tameskill'})
    {
        if ($nature) {$nature .= "<br>";}
        $nature .= "tameskill ${$currententry}{'tameskill'}";
    }
    
    if (!$nature) {$nature = '&nbsp;';}
    print NPCPAGE "<td valign=top align=center>$nature</td>\n";
    
    $skills="";
    foreach $skill (@skillsarray)
    {
        if (${$currententry}{$skill})
        {
            if ($skills) {$skills .= "<br>";}
            $skillid = $skill;
            $skill =~ s/identification/id/;
            $skill =~ s/evaluatingintelligence/evalint/;
            $skill =~ s/forensicevaluation/forensic/;
            $skill =~ s/magicresistance/resist/;
            $skill =~ s/detectinghidden/detecthidden/;
            $skills .= "$skill ${$currententry}{$skillid}";
        }
    }
    
    if (!$skills) {$skills = '&nbsp;';}
    print NPCPAGE "<td valign=top align=left>$skills</td>\n";
    
    ${$currententry}{'attackskillid'} =~ s/^\s*//;
    @AS = split //, ${$currententry}{'attackskillid'};
    $AS[0]= uc($AS[0]);
    print NPCPAGE "<td valign=top align=left>$AS[0]</td>\n";
    
    print NPCPAGE "<td valign=top align=center>${$currententry}{'attackspeed'}</td>\n";
    
    print NPCPAGE "<td valign=top align=center>${$currententry}{'attackdamage'}</td>\n";
    
    if (!(${$currententry}{'ar'})) {${$currententry}{'ar'} = '&nbsp;';}
    print NPCPAGE "<td valign=top align=center>${$currententry}{'ar'}</td></tr>\n\n";
    
}


print NPCPAGE <<EOF;

<tr>
<td colspan=14 align=center style="font-size : medium; font-weight: bold"><a name="extra">Extraplanar</a></td></tr>
<tr><th align=center>Template</th>
<th align=center>Script</th>
<th align=center>ObjType</th>
<th align=center>STR</th>
<th align=center>DEX</th>
<th align=center>INT</th>
<th align=center>Flags</th>
<th align=center>Nature</th>
<th align=center>Skills</th>
<th align=center>AS</th>
<th align=center>Atk Spd</th>
<th align=center>Dmg</th>
<th align=center>AR</th></tr>

EOF

while ($currententry = shift @npcextraplanar)
{
    
    print NPCPAGE "<tr><td valign=top align=left>${$currententry}{'npctemplate'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'script'}</td>\n";
    print NPCPAGE "<td valign=top align=center>${$currententry}{'objtype'}<br>${$currententry}{'color'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'str'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'dex'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'int'}</td>\n";
    
    my $flags="";
    if (${$currententry}{'settings'} =~ /invul/i) {$flags .= "I";}
    if (${$currententry}{'guardignore'} =~ /1/i) {$flags .= "i";}
    if (${$currententry}{'alignment'} =~ /evil/i) {$flags .= "e";}
    if (${$currententry}{'alignment'} =~ /good/i) {$flags .= "g";}
    if (${$currententry}{'alignment'} =~ /neutral/i) {$flags .= "n";}
    if (${$currententry}{'guardkill'} or ${$currententry}{'nocorpse'}) {$flags .= "c";}
    if (${$currententry}{'undead'}) {$flags .= "u";}
    
    if (!$flags) {$flags='&nbsp;';}
    print NPCPAGE "<td valign=top align=left>$flags</td>\n";
    
    $nature = "";
    if (${$currententry}{'speech'}) {$nature .= "speech ${$currententry}{'speech'}";}
    if (${$currententry}{'provoke'}) 
    {
        if ($nature) {$nature .= "<br>";}
        $nature .= "prov ${$currententry}{'provoke'}";
    }
    
    if((${$currententry}{'lootgroup'}) or (${$currententry}{'magicitemchance'}))
    {
        if ($nature) {$nature .= "<br>";}
        $nature .= "lootgroup ${$currententry}{'lootgroup'}";
        if (${$currententry}{'magicitemchance'}) {$nature .= "/${$currententry}{'magicitemchance'}";}
    }
    
    if (${$currententry}{'tameskill'})
    {
        if ($nature) {$nature .= "<br>";}
        $nature .= "tameskill ${$currententry}{'tameskill'}";
    }
    
    if (!$nature) {$nature = '&nbsp;';}
    print NPCPAGE "<td valign=top align=center>$nature</td>\n";
    
    $skills="";
    foreach $skill (@skillsarray)
    {
        if (${$currententry}{$skill})
        {
            if ($skills) {$skills .= "<br>";}
            $skillid = $skill;
            $skill =~ s/identification/id/;
            $skill =~ s/evaluatingintelligence/evalint/;
            $skill =~ s/forensicevaluation/forensic/;
            $skill =~ s/magicresistance/resist/;
            $skill =~ s/detectinghidden/detecthidden/;
            $skills .= "$skill ${$currententry}{$skillid}";
        }
    }
    
    if (!$skills) {$skills = '&nbsp;';}
    print NPCPAGE "<td valign=top align=left>$skills</td>\n";
    
    ${$currententry}{'attackskillid'} =~ s/^\s*//;
    @AS = split //, ${$currententry}{'attackskillid'};
    $AS[0]= uc($AS[0]);
    print NPCPAGE "<td valign=top align=left>$AS[0]</td>\n";
    
    print NPCPAGE "<td valign=top align=center>${$currententry}{'attackspeed'}</td>\n";
    
    print NPCPAGE "<td valign=top align=center>${$currententry}{'attackdamage'}</td>\n";
    
    if (!(${$currententry}{'ar'})) {${$currententry}{'ar'} = '&nbsp;';}
    print NPCPAGE "<td valign=top align=center>${$currententry}{'ar'}</td></tr>\n\n";
    
}


print NPCPAGE <<EOF;

<tr>
<td colspan=14 align=center style="font-size : medium; font-weight: bold"><a name="other">Other</a></td></tr>
<tr><th align=center>Template</th>
<th align=center>Script</th>
<th align=center>ObjType</th>
<th align=center>STR</th>
<th align=center>DEX</th>
<th align=center>INT</th>
<th align=center>Flags</th>
<th align=center>Nature</th>
<th align=center>Skills</th>
<th align=center>AS</th>
<th align=center>Atk Spd</th>
<th align=center>Dmg</th>
<th align=center>AR</th></tr>

EOF

while ($currententry = shift @npcother)
{
    
    print NPCPAGE "<tr><td valign=top align=left>${$currententry}{'npctemplate'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'script'}</td>\n";
    print NPCPAGE "<td valign=top align=center>${$currententry}{'objtype'}<br>${$currententry}{'color'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'str'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'dex'}</td>\n";
    print NPCPAGE "<td valign=top align=left>${$currententry}{'int'}</td>\n";
    
    my $flags="";
    if (${$currententry}{'settings'} =~ /invul/i) {$flags .= "I";}
    if (${$currententry}{'guardignore'} =~ /1/i) {$flags .= "i";}
    if (${$currententry}{'alignment'} =~ /evil/i) {$flags .= "e";}
    if (${$currententry}{'alignment'} =~ /good/i) {$flags .= "g";}
    if (${$currententry}{'alignment'} =~ /neutral/i) {$flags .= "n";}
    if (${$currententry}{'guardkill'} or ${$currententry}{'nocorpse'}) {$flags .= "c";}
    if (${$currententry}{'undead'}) {$flags .= "u";}
    
    if (!$flags) {$flags='&nbsp;';}
    print NPCPAGE "<td valign=top align=left>$flags</td>\n";
    
    $nature = "";
    if (${$currententry}{'speech'}) {$nature .= "speech ${$currententry}{'speech'}";}
    if (${$currententry}{'provoke'}) 
    {
        if ($nature) {$nature .= "<br>";}
        $nature .= "prov ${$currententry}{'provoke'}";
    }
    
    if((${$currententry}{'lootgroup'}) or (${$currententry}{'magicitemchance'}))
    {
        if ($nature) {$nature .= "<br>";}
        $nature .= "lootgroup ${$currententry}{'lootgroup'}";
        if (${$currententry}{'magicitemchance'}) {$nature .= "/${$currententry}{'magicitemchance'}";}
    }
    
    if (${$currententry}{'tameskill'})
    {
        if ($nature) {$nature .= "<br>";}
        $nature .= "tameskill ${$currententry}{'tameskill'}";
    }
    
    if (!$nature) {$nature = '&nbsp;';}
    print NPCPAGE "<td valign=top align=center>$nature</td>\n";
    
    $skills="";
    foreach $skill (@skillsarray)
    {
        if (${$currententry}{$skill})
        {
            if ($skills) {$skills .= "<br>";}
            $skillid = $skill;
            $skill =~ s/identification/id/;
            $skill =~ s/evaluatingintelligence/evalint/;
            $skill =~ s/forensicevaluation/forensic/;
            $skill =~ s/magicresistance/resist/;
            $skill =~ s/detectinghidden/detecthidden/;
            $skills .= "$skill ${$currententry}{$skillid}";
        }
    }
    
    if (!$skills) {$skills = '&nbsp;';}
    print NPCPAGE "<td valign=top align=left>$skills</td>\n";
    
    ${$currententry}{'attackskillid'} =~ s/^\s*//;
    @AS = split //, ${$currententry}{'attackskillid'};
    $AS[0]= uc($AS[0]);
    print NPCPAGE "<td valign=top align=left>$AS[0]</td>\n";
    
    print NPCPAGE "<td valign=top align=center>${$currententry}{'attackspeed'}</td>\n";
    
    print NPCPAGE "<td valign=top align=center>${$currententry}{'attackdamage'}</td>\n";
    
    if (!(${$currententry}{'ar'})) {${$currententry}{'ar'} = '&nbsp;';}
    print NPCPAGE "<td valign=top align=center>${$currententry}{'ar'}</td></tr>\n\n";
    
}

print NPCPAGE "</table>";
