Carpentry with Add-Ons

Instructions
============

Unpack all files at pkg\std\carpentry

Don't Forget to compile all files

How to Place an Add-On?
=======================

  You just can place Add-Ons in houses owed by you. The add-on is placed where you are standing

How to set Up New Add-Ons?
=============================

  I've changed caroentry.cfg a lot, so take a look here how it works right now:
  
  Name : Name of the item
  material: how many logs do it takes to make it?
  skill: what are the carpentry skill reqs for making it?
  skill2: what are the sendond skill reqs for making it?
  material2: how many of the second material do it takes to make it?
  material2obj: the other material objtype?
  skillID: Skill ID of the second skill
  type: type of the item, for carpentry menu proposes: (1:Furniture,2:Storage,3:Misc,4:Add-Ons)
  icon: icon that appears in carpentry menu
  Objtype: what item is created if it pass in skill checks

ToDo
====

  Need to add Support for Multiple Tile Add-Ons
  Support To destroy craftables

Charles Haustron