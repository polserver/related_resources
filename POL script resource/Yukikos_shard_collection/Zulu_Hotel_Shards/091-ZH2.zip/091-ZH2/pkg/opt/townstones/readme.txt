to start the voting you can type or mayor can set it
.setobjproperty eleicao 1
