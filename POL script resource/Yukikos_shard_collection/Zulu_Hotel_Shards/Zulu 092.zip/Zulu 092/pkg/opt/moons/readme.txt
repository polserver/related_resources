
A silly little script that makes the moons go. Felucca changes phase
every 30 seconds, Trammel every 90 seconds. It's tweakable in the
script, though it would take a little bit of work to make Trammel not
3x Felucca, which I did because it's consistant with Ultimas III and IV.
 
You need to comment out the line for the telescope in itemdesc.cfg before
enabling this package.

Defines a new item, the spyglass, which when doubleclicked tells you the
moonphases. 
New textcommand, .lookup, does the same thing as the spyglass. (Why should
you need a spyglass to see the moons?) I did both because I will someday 
add more hooks to the spyglass, such as seeing comets.

Future project- link the moongates directly to the moons.