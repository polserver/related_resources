2 files are included:-

makeraxweapon.src - which will make any weapon selected into an enhanced unique weapon (added to
make manual file editing unecessary). Compile and copy to /scripts/textcmd/admin.

raxweapon.src - the hitscript itself. Alter the max and min damage values for each effect to suit
your needs before compiling. Compile and copy to Pkg/Std/Combat.

This hitscript enhances a normal weapon to give a 10% chance of releasing a magical effect onto
your foe. Effect entries are marrow,harm,fireball,lightning,ebolt & fstrike.
Warning: these spell effects do take magic resistance into account but ignore spell reflect due
to the weapon being in direct contact with the defender.

Use this or play around with it as much as you like but if you do make any additions of major
enhancements please make sure i get a copy at raxxla@dial.pipex.com or better still, post to the
POL onelist for all to use, thx :)