You will need to add the following to your POL/config/fileaccess.cfg file.

FileAccess
{
	Package		ScriptLogger
	
	AllowRead	1
	AllowWrite	1
	AllowAppend	1
	
	Extension	.log
}