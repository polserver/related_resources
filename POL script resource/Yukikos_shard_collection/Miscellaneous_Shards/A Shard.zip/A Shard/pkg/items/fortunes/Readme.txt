My first attempt at scripting from scratch, nothing too flashy, 
just 3 fortune telling scripts which use crystal balls, runes and tarot cards.

Please be gentle with the feedback!

Neil Graham
Basara@Mytharria.com