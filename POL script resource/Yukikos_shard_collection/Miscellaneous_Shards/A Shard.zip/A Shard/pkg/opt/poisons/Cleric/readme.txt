Invulnerability poison by Austin Heilman
Email aheilman@home.com
ICQ   241828

Installation

Place a folder in your poison watcher package called
"Cleric" extract the .src files in this zip to that
newly created folder. Append the contents of this poisons.cfg
to your poisons.cfg in the posion watcher package.
