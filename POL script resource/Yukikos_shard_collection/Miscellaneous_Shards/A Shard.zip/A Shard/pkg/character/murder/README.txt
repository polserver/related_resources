Welcome to Racalac's hard-to-install Murder System v1.0!

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
FOLLOW ALL DIRECTIONS TO THE LETTER OR YOU WILL BE SHOT!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

*** THIS SYSTEM REQUIRES CORE 090 OR LATER!!

This system is already integrated and fully tested with the POL090 full server. You do not need
this system if you are using the POL090 scripts! 

Files in this zip:
README.txt
chrdeath.txt
logon.txt
logoff.txt
reportmurder.inc
res.inc
respenalty.inc
consider.src
/timer
/timer/start.src
/timer/timers.src
/timer/pkg.cfg

To install:

/timer: (ONLINE TIMER)
extract the /timer directory in the zip file and all files therein to /pkg/std/timer

chrdeath.txt: (ACTIVATES MURDER REPORTING GUMP)
add the include line in chrdeath.txt right above the "program chrdeath.." line in scripts/misc/chrdeath.src
add the code in chrdeath.txt to the bottom of the chrdeath() function in scripts/misc/chrdeath.src

logon.txt: (FOR ONLINE TIMER)
Add the code to /scripts/misc/logon.src near the top.

logoff.txt: (FOR ONLINE TIMER)
Add the code to /scripts/misc/logoff.src anywhere.

reportmuder.inc: (FOR REPORT GUMP)
res.inc: (FOR "Res Now?" GUMP ON RESURRECTION)
respenalty.inc: (FOR PENALTIES ON RESURRECTION)
-Add the above files to scripts/include.

consider.src: (FOR MURDER COUNTS)
add to /scripts/textcmd/player

You need to edit all the scripts that can resurrect a character to use the functions in res.inc
and respenalty.inc. Remember to add

include "include/res";
include "include/respenalty";

at the top of the script. If you have trouble seeing where this code goes, here's the general
idea: Where the script did just resurrect the player, you wrap an if statement around it checking
if(ResNow(mobile)=1). After you res, call ResPenalties(mobile) .

This is a list of scripts I had to edit:

/pkg/std/healing/healing.src, line 202, right under "if ( roll < chance )"
        if(ResNow(patient)=1)
            resurrect( patient ); //was already here
            ResPenalties(patient);
            SendSysmessage ( character, "You have resurrected the patient." );
        else
            SendSysmessage ( character, "The patient refused resurrection." );
        endif

/pkg/std/spells/resurrect.src, line 35, right under "PlaySoundEffect(cast_on, SFX_SPELL_RESSURECTION);"
	if(ResNow(cast_on)=1)
		Resurrect( cast_on );  //was already here
		ResPenalties(cast_on);
	endif

/pol/scripts/items/resfield.src, line 24, right after "if (Distance( mobile, floor ) = 0)"
        if(ResNow(mobile)=1)
            PlaySoundEffect( mobile, SOUND_EFFECT_RES );  //was already here
            mobile.poison_level := 0; // cure poison...   //same
            Resurrect( mobile );  //same
            ResPenalties(mobile);
            PlayObjectCenteredEffect( mobile, EFFECT_SPARKLE, 10,10); //same
        endif

/pol/scripts/include/creature_spellcast.inc, Resurrect() function, right after the !CheckLineOfSight endif
	if(ResNow(cast_on)=1)
    	    PlaySoundEffect(caster, SOUND_EFFECT_CURE);  //this was already here
            PlaySoundEffect(cast_on, SOUND_EFFECT_CURE); //same

    	    Resurrect( cast_on );  //was already here
    	    ResPenalties(cast_on);
        endif

RECOMPILE ALL SCRIPTS TO BE SURE CHANGES HAVE TAKEN EFFECT.

Basic Structure of this implimentation:

	When a player dies, he is presented with a list of the other PCs that damaged him
since the time he was fully healed. The player can report all, some, or none of these players.
Those players he reports get their short and long term murder counts incremented, and their
decay timers reset to 8 and 40 hours, respectively. If this murder was their 5th or more 
long term murder count, the player is red (player.setmurderer(1)). If it was their 5th or more
short term count, the player will be subject to stat loss proportional to the number of 
short term counts. If the "ping-pong" counter is 5 or more, the "permared" flag is set.
The player may use the ".consider" text command to "consider their sins" 
which gives them a textual message about the status of the murder counters, if they are 
subject to statloss, their murderer status, and their permared status.
	In the included timer package is my implimentation of an online-timer for players. 
The murder system uses this to decay murder counts, but it can be used for other things
beyond the scope of this system. Every 5 minutes the timer wakes up and updates the onlinetimer cprop,
checks the online timer against the decay time of the next count. If it is time, it will decrement 
the appropriate count, reset the timer for the next count, and, if appropriate, setmurderer(0) 
(less than 5 long term counts).

Here are the list of the added cprops:

logontime: gameclock value when the character last logged in, used to calculate onlinetimer
onlinetimer: number of seconds this character has been played since we started counting
shortmurders: number of short-term murder counts
longmurders: number of long-term murder counts
decayshortat: the amount of seconds the onlinetimer should be at before we decay a short-term count
decaylongat: same as above for long counts
pingpong: number of times the player has gone from the state of stat-loss to no-stat-loss 
permared: is set true when pingpong is 5 or more, never changes after that

List of Consequences:
1. shortmurders >= 5 : player incurs statloss for a percentage equal to shortmurders (max of 20%)
2. longmurders >= 5 : player is red (murderer), no other penalty
3. pingpong >= 5 : player is permanently red, only statloss if #1 is true. does not decay.
4. permared: permanently murderer

I really hope everything goes well for you, and if not, re-read everything.
-Rac