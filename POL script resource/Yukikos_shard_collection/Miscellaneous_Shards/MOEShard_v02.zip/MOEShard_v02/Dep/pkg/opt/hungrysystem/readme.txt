Hungry System Version 0.1

Instructions
============

Copy/Move eat.src to /scripts/items and to /pkg/std/cooking Then Create a New Pkg to the other
files

Don't Forget to compile all files

How Does it Work?
=================

  The "Hungry" of each player(Anyone with level above 0 is not affected by hungry) has 10 level,
10 the players is very well feed and 1 he is starving.   The Hungry System in time to time(each
30 minutes is default) will decrease 1 level of each player and apply the effects going down to
that level. Each time a player eats something, he goes up one level.

ToDo
====

  Add some other nice effects for hungry players, and some benefits for beeing well feed.
Expection some help here.

Charles Haustron