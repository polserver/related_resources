Name MOEShard
Maintainer M.o.E
Email m.o.e@moe99.cjb.net

These sripts are published without any warranty, they are not completely tested so there could (will)
be some bugs in them. If you find a bug, fix it and send the fix to me, please. If you can't fix the
bug send it to me (m.o.e@moe99.cjb.net) with exact desciptions of the bug and how to reproduce it
(with example code). If my time permits, I'll then try to fix it.

Credits:
I only could do all my scripts and pkgs (that fast) because of spying and reusing code of other
authors. So here I will give some credits to the valuable work of these authors. Of some code I
don't know the authors so I'll mention the ones I know:

Angreal
Dream Weaver
Drocket
GM Scull
Hammerstorm
Madman Across the Water
Oroborous
Racalac
Sigismund
Shilohen
Zulu
...........

That's why I'll publish my work here to share it with the POL community and hope it will be useful
to someone out there.

My History:
I started with UO when I found the software on a CD-Rom of a game magazine in germany (PC-Player).
This game magazine was the best in germany until the 'future publishing house' bought it and decided
to give that magazin no future anymore, but thats another story.
Well with that CD I started to play within the trail time (2 weeks or so) on OSI shards. I was
impressed of the possibilities you have in the game. After the trail time I searched for a
possibility to continue playing UO without paying the fee to OSI.
With searching on the internet I found some UO-emulatores, so I began to read the documetations of
the emulators and started with UOX3. First it was simple to change some things like items and
crafting possibilities but I wanted to make some more complex changes and there fast I found the
limits of the scripting posibilities of UOX3. Than I changed to Sphere. But here I couldn't manage
to implement the things I want (apart of new items and changing the crafting possibilities and
triggers), too. Mainly because of the lack of documentation and script examples.
So I came to POL and started with 'Racalac's eScript Reference and Guide' and since then I'm a great
fan of POL. Then I started to develop my own 'offline' shard and here is it.

Intro:
The first pkg I did was the Race/Class-System, mainly extended Dream Weavers classsystem with a race
system. That's the reason why almost everything I did depends on my raceclasssys. You will find my
pkgs in the /pkg/opt folder. There are readme files in each of my pkgs. In the /Dep folder you will
find all the changes and bugfixes I did to existing scripts and pkgs, e.g. all necessary changes for
my raceclasssys, snooping, steeling, necromancy, ...

Installation:
Install the full server (092-full.zip) edit the pol.cfg ,accounts.txt and servers.cfg, then copy
/pkg, /config, /scripts to the pol root folder and override all files. Then change to the Dep folder
and copy everything (recursively) to pol root folder, overriding all files. Recompile the folders
pkg and scripts recursively in your pol installation and then start the pol server and have fun.
Well you have to set up the race and class joining area for the raceclasssys (see readme.txt in the
raceclassssys pkg).

Files:
All Pkgs: See the readme.txt files in the pkg folders.

escort.src (scripts/ai): Travel NPC which pays a PC to escort him/her to a destination.
Commands:
info: Informatio about the destination and the money he/she will pay
escort: Accept to escort him/her.
mount,ride:     Mount a horse, ostard,...
dismount:       Dismount a horse, ...
move:           Moves a little away from you (e.g. if you are blocked)
help:           Search and fight enemy.
brb:            Clear event queue
stuck:          Try to free a stuck NPC
release
speak

escort.cfg (config): Config file for the travel destinations of the escort NPC.

pcmirror.src (scripts/ai): NPC mirror of the PC. For complete command set see conjuration or hirelings
pkg. Start script see awardsystem pkg.

tamed.src (scripts/ai): Rewrite of the tamed ai with my supportpc ai. (see also conjuration,
hirelings pkg and pcmirror.src.

corpsecontrol.src (scripts/control): Changes the PC corpse to bones before decaying.

karmafame.inc (script/include): Karma/Fame system.

karmafame.cfg (config): Config file to categorize the NPCs due to their ai scripts to determine the
NPC karma/fame amount (pos., neg., neut.) for the Karma/Fame system.

PS:
Please apologize my poor english and my poor documentation.

Feedback:

If you have questions or bugfixes, please send them to m.o.e@moe99.cjb.net
Also positiv feedback are welcome.

