Name    resnpc
Version 0.1
Maintainer M.o.E
Email m.o.e@moe99.cjb.net

These sripts are published without any warranty, they are not completely tested so there could (will)
be some bugs in them. If you find a bug, fix it and send the fix to me, please. If you can't fix the
bug send it to me (m.o.e@moe99.cjb.net) with exact desciptions of the bug and how to reproduce it
(with example code). If my time permits, I'll then try to fix it.

Intro:
The resurrect NPC package basically does what it says, it resurrects NPCs. You resurrect the NPC by
targeting the corpse of it. Normal NPC will be resurrected with standard npctemplate skills and
stats, NPCs with a rune of memory in the backpack/corpse will be resureccted with all its skills,
stats, attributes and cprops the NPC have had before dead (only a master of tamed, conjured,... NPC
can resurrect a NPC with a rune of memory).
So if you want to memorize the attributes of a tamed, conjured,... (cprop "master" := char) you have
to give the NPC a rune of memory (using CreateMemoryRune( who) from the resnpc.inc file).
To resurrect a NPC dobbleclick the rune of memory or call the resurrect.src script with whatever you
like (your item or from your custom skillwin).
A skill of 80 or more in healing or magery is necessary to succeed in resureccting a NPC.

Files in the package:
pkg.cfg (pkg/opt/resnpc): Package config file.

ctrl_reg.src (pkg/opt/resnpc): Script to register this package with the control package.

itemdesc.cfg (pkg/opt/resnpc): Definition of the rune of memory.

copydate.src (pkg/opt/resnpc): Control script of the rune of memory which copies the data from the
NPC to the rune of memory. (modify the delay (WAITDELAY) between the copy runs to your convenience)

resurrect.src (pkg/opt/resnpc): The script which resurrects the NPC. If the corpse have a rune of
memory, it returns the data from the rune of memory and equips the NPC with the items in the corpse
container.

resnpc.inc (scripts/include): The include script with the CreateMemoryRune( who) function, to create
the rune of memory within your tamed, conjured, ... NPC scripts.

Feedback:

If you have questions or bugfixes, please send them to m.o.e@moe99.cjb.net
Also positiv feedback are welcome.

