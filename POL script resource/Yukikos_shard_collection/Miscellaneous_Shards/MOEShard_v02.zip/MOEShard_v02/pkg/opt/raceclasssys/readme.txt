Race/Class  System Readme
version 0.1
by M.o.E - 03.2001
email: m.o.e@moe99.cjb.net
used parts from Dream Weaver's (windminstrel@home.net) class system

These sripts are published without any warranty, they are not completely tested so there could (will)
be some bugs in them. If you find a bug, fix it and send the fix to me, please. If you can't fix the
bug send it to me (m.o.e@moe99.cjb.net) with exact desciptions of the bug and how to reproduce it
(with example code). If my time permits, I'll then try to fix it.
So enjoy (after a lot of sweat) the new and fabulous race/class system.

Ok, here's the basics of my race/class system: When a character is created, he's taken (via the oncreate script)
to a race selection area we have set up. There are some race leaders (AI is RACELEADER.src), when a player wants to accept
a race says "join" to the race leader.
After that you go to the guildmaster area.
We have masters of each class set up there (AI is GUILDMASTER.src).
When a player wants to join the class, he says "join" to the master. His skills are all zeroed, and he selects his personal primary skill.
That skill is trained to 60, and all other class-primary skills are trained to 40. The rest are left at zero.
Their stats are checked to make sure they meet class specifics. From there they're whisked off to the starting area.

The race a character effects him in several ways:
Stats: the race defines the stat caps.

Skills: Each race have skills which can they learn faster or slower.
inc1: slightly increased skilladvance in that skill
inc2: increased skilladvance in that skill
inc3: significant increased skilladvance in that skill
dec1: slightly slower skilladvance in that skill
dec2: slow skilladvance in that skill
dec3: significant slower skilladvance in that skill

Each race only permits to join certain classes.

The class a character effects him in several ways:
Stats: each class has a primary, secondary, and tertiary stat. Secondary will never exceed primary, nor tertiary the secondary.

Skills: Each class has primary, secondary, penalty, and denied skills:
primary: primary skills can go to 100, and have increased skill gain
secondary: secondary skills can go to 80, and gain at the normal rate
penalty skills: these cannot go above 40, and gain slowly
denied: these skills remain at zero, and the character can't use the skill

Furthermore, each character has a personal primary skill he selects when the character joins the class.
These skills grow at an accelerated rate and will start with 60 skill points.

Finally, some classes have class-specific skills that replace other skills in the window.
For example, an druid might have a shapechange skill. This is set in classes.cfg as well.

Race/Class restrictions: Different races/classes are limited on weapons, armor and spells. 

Files included in this distribution:

advcheckskill.inc (scripts/include): this is the include file you need in all skill use scripts.
You have to change each call to CheckSkill(...) with AdvCheckSkill(...) in scrips and add advcheckskill.inc to
the script. Lot of work, sorry!

magicinsresrestr.inc (scripts/include): this is the include file you need in all spell, inscription use
scripts.
Replace all StartSpellEffect(...) with AdvStartSpellEffect(...).
Replace all StartSpell(...) with AdvStartSpell(..).
Replace all ZuluStartSpell(who) with AdvZuluStartSpell( who, spellid), for AdvZuluStartSpell you
have to give a convinient spellid as additional parameter.
Replace all ScribeScroll(...) with AdvScribeScroll(...).
Replace all enchant_item(...) with AdvEnchantItem(...).
Replace all InscribeNecroSpell(...) with AdvInscribeNecroSpell(...).
More work, think about it if you still want to continue!! I say it's worth it.

races.cfg (pkg/opt/raceclasssys): the file that determines all races. Here's an example:

race Xyz // race name
{

strcap	120 // str cap for this race
dexcap	100 // dex cap for this race
intcap	90 // int cap for this race

efficiencyboost	10 // efficiency of learning for this race: the chance in
                   // percent to get a second skill check and so a second chance to advance in
                   // this skill (but not a second chance to succeed in this skill)

graphic 0x11 // graphic of the char
require 0x204B // need to be equipt with 0x204B (med-short beard)
require 0x203C // need to be equipt with 0x203C (long hair)
colorskin	443 444 // skincolor form value to value
colorhair	901 904 // haircolor form value to value

inc1	40 // advanced increase (marginally) in skill 40 (comulativ with class skill advances)
inc2	41 // advanced increase (more) in skill 41
inc3	7 // advanced increase (significant) in skill 7
dec1	45 // marginally slower advanced in skill 45
dec2	37 // slower advanced in skill 37
dec3	12 // very slow advanced in skill 12
         // the amount of increases and penalties (dec1 - dec3) are defined in
         // advcheckskill.inc (INC1 - INC3 and DEC1 - DEC3)

class Warrior // allowed class with this race
class Cleric
class Rogue
class Metalworker
class Artisan

}

classes.cfg (pkg/opt/raceclasssys): the file that determines all classes.  Here's an example:

class Druid // class name
{

stat1 intelligence // stat1 = most important stat for this class
stat2 dexterity // stat2 = second stat for this class
stat3 strength // stat3 = not very important stat for this class

Skill 6/Shapeshifting/:shapechange:shapechange/1/46 // skill replacement:
                                                    // replaces skill 6 (begging) in
                                                    // skillwindow with skill Shapeshifting
                                                    // which calls the script shapechange in
                                                    // pkg shapechange, which is an active
                                                    // skill and checks the skill 46 (meditation)
                                                    // General format:
                                                    // skillnumber/DisplayName/Script/Active=1
                                                    // or Passiv=0/skillnumber used in
                                                    // CheckSkill(...)

Skill 6/Shapeshifting                               // this would replace skill 6 with
                                                    // Shapeshifting but would use the default
                                                    // script for skill 6, show the skillval
                                                    // for skill 6 and only appears as active
                                                    // if skill 6 is an active skill.
                                                    // Though not very useful in this case it's only
                                                    // here to show you that some parts are optional.

Primary 39 // primary (class) skills for that class (are advancing faster as normal and up to 100)
...        //  (comulativ with race skill advances)
...
Primary 25

Penalty 29 // penalty skills for that class (are advancing slower as normal and up to const
...        // PENALTY_SKILL in skilladv.src (40)
...
Penalty 44

Denied 40 // denied skill for this class
...
Denied 6
         // all skill not defined here are secondary skills for that class
         //(are advancing a bit faster as normal and up to const NORM_SKILL in skilladv.src (80)

         // the amount of increases and penalties are defined in
         // advcheckskill.inc (PRIMARY_BONUS, CLASS_BONUS, PENALTY)
}

classeqp.cfg (pkg/opt/raceclasssys): Define here your start equipment for the classes.

classsskills.inc (pkg/opt/raceclasssys): shows the class-primary skills to the character, so he can select personal primary skill.
Gump designed by Racalac

equiptest.src (scripts/misc): determines whether or not a character can equip an item

caninsertscroll.src(scripts/control): determines whether or not a character can inscribe a scroll to
the spellbook. (insert 'CanInsertScript caninsertscroll' to your Spellbook in config/itemdesc.cfg)

scrollinsert.src(scripts/control): determines whether or not a character can inscribe a scroll to
the spellbook.

raceleader.src (scripts/ai) : the race leader, who helps a character to accept a race.
Note that cProp line1..cprop lineX are lines of text he'll tell you about the race

guildmaster.src (scripts/ai) : the guildmaster, who helps a character into a class.
Note that cProp line1..cprop lineX are lines of text he'll tell you about the class

itemdesc.cfg (pkg/std/combat): has entries in the weapons to show how to set class-specific items.
Needed for race/class restrictions on weapons and armor. (example)

spells.cfg (pkg/std/spells): has entries in the spells to show how to set class-specific spells
Needed for race/class restrictions on spells. (example)

joinrace.inc (pkg/opt/raceclasssys) : Does most of the work for the race leader

joinclass.inc (pkg/opt/raceclasssys) : Does most of the work for the guildmaster

leaveclassarea.src (pkg/opt/raceclasssys): A (location-hardcoded) script for moongates that won't let people
leave the race/class area without class/race

npcdesc.cfg (config): look here for examples the raceleader and guildmaster settings (add yours to your npcdesc.cfg
file)

oncreate.src (scripts/misc) : whisks a character off to MY race-selection area. Edit this and put in your own location!

itemdesc.cfg (pkg/opt/raceclasssys) :  a moongate to leave race and class selection area (uses
leaveclassarea.src)

skilladv.src (scripts/misc): this script checks to make sure that you don't go above the proper level in a skill,
that your stats are in the proper order to your selected race, and that they're beneath the total global stat cap.
It also sets your class title when you advance in your personal primary skill.

skillwin.src (scripts/misc): This one is the biggie. This is the new skill window, that takes care of renaming skills
and showing the corresponding skillvalue.

unequiptest.src (scripts/misc): unequip test script. Not much for the class system, but fun for cursed weapons!
Also checks if you are an animal (my shapechange pkg) which causes no changing of equipment if you are an animal at the moment.

ctrl_reg.src (pkg/opt/raceclasssys): Script to register this package with the control package.

Other stuff you want to change:

advcheckskill.inc consts:
PRIMARY_BONUS:    Bonus to receive for the personal selected class primary skill.
CLASS_BONUS:      Bonus to receive for the class primary skills.
PENALTY:          Penalty to receive for the class penalty skills.
INC1 - INC3:      Bonus to receive for the race specific increase skills, INC1 marginally
                  increase to INC3 significant high increase.
DEC1 - DEC3:      Negative bonus to receive for the race specific penalty skills,
                  DEC1 marginally slower skilladvance to DEC3 significant slower skilladvance.
FASTSTATADV:      Fast stat advance (1 = true, 0 = false). // Hack
                
These values are comulative.
E.g.: PRIMARY_BONUS = 1.5;
      INC2 = 1.4;
      
      So if your race have an increase (inc2) skill for alchemy (0) and you class have alchemy as primary
      skill the total advance factor for alchemy is 2.1 !

skilladv.inc consts:
STATCAP:        Statcap for all stats (str+dex+int).
NORM_SKILL:     Cap for secondary skills (class).
PENALTY_SKILL:  Cap for penalty skills (class).


Known Bugs:

The config files seem to be case-sensitive, and I'm too lazy to change the scripts to deal with it.


Feedback:

If you have questions or bugfixes, please send them to m.o.e@moe99.cjb.net
Also positiv feedback are welcome.

