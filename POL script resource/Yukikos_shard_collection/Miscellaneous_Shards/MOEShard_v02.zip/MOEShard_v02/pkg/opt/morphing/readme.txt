Name morphing
Version 0.1
Requires raceclasssys 0.1
Requires awardsystem 0.1
Maintainer M.o.E
Email m.o.e@moe99.cjb.net

These sripts are published without any warranty, they are not completely tested so there could (will)
be some bugs in them. If you find a bug, fix it and send the fix to me, please. If you can't fix the
bug send it to me (m.o.e@moe99.cjb.net) with exact desciptions of the bug and how to reproduce it
(with example code). If my time permits, I'll then try to fix it.

Intro:
A morpher can change to all forms, NPCs and PCs, on the shard, if he/she has the proper skill. With
morphing to the other form he/she gets all the skills and stats, race, class, name, titel,... from
the original so he/she is a 'copy' of the original. If the original is a NPC with spells in the
npctemplate the morpher will receive a temporary spellbook with these spells and if the NPC is a
firebreather he/she will receive the temp posibility to firebreath with an award in his awardbook
(see my awardsystem pkg). When a morpher changes his/her form there is always a chance (dep. on
meditation skill) to return to org. form automatically. Also the morpher in a new form will lose all
of his/her original skills and stats. When he/she returns to original form all the skills and stats
return to the values the morpher had before morphing to another form.

You need the anatomy and animallore skill to get the information about the creature and the
meditation skill to morph.

Files in the package:
pkg.cfg (pkg/opt/morphing): Package config file.

ctrl_reg.src (pkg/opt/morphing): Script to register this package with the control package.

itemdesc.cfg (pkg/opt/morphing): Definition of the temp. spellbook and the Ring of Return From.

morphbook.src (pkg/opt/morphing): Script for th temp. spellbook gump.

creaturebook.inc (scripts/include): Used from morphbook.src.

pccast.inc (scripts/include): Used from creaturebook.inc to cast from temp. spellbook.

morphing.src (pkg/opt/morphing): Script used to morph to a new form.

morphlive.src (pkg/opt/morphing): Script to start the morph live cycle.

morphring.src (pkg/opt/morphing): Ring of Return From script to return to original form.

morphtocreature.inc (pkg/opt/morphing): Main morphing functions. (The heart of the pkg)

logofftest.src (scripts/misc): Includes part for this pkg to prevent problems with restarting the
server when the char logged out in e.g. animal form.

logon.src (scripts/misc): Includes part for this pkg to prevent problems with restarting the server
when the char logged out in e.g. animal form and starts the live cycle for that form.

Feedback:

If you have questions or bugfixes, please send them to m.o.e@moe99.cjb.net
Also positiv feedback are welcome.

