pc_combat_script.src
this is the script that is used for players


itemdesc.cfg
this is a complete list of all weapons

pkg.cfg
never delete this, it makes sure that this directory is loaded when doing a startup!

other files:
old junk
