Poison Watcher by Austin Heilman
Email: Austin@tsse.net
Shard: http://www.tsse.net

Background: This controller renders the existing cprop poison systems obsolete.
It is designed to manage seperate scripts that do the acutal poisoning. The 
poison watcher will keep track of durations and makes healing, poisoning, cursing
etc. significantly easier.

Installation: Extract the files in the zip to a folder in pkg/opt/ or pkg/std; either way 
doesnt really matter. You could even just go pol/pkg/poison watcher.
Copy the poisons.inc file into your /scripts/include folder.

At the top of your logouttest.src file in pol/scripts/misc place the line
EraseObjProperty(who, "#Online"); so the poison watcher knows when to stop.

Reference: Below are functions in poisons.inc which you will use in scripts
that need to deal with the poison watcher.

Functions and descriptions in poisons.inc

ListPoisonsByType(mobile, the_type)
Use this function to find all the poisons of a certain type on a mobile.
An example would be ListPoisons(who, "C") which would return an array of
all curses the person is infected with. the_type is 'not' case sensitive
but it relies on the poisons.cfg to determine what the poison type is.
To hide a poison from this function, just do not specify a type for it in
the config.

GetAllPoisons(mobile)
Returns "every" single thing the mobile is infected with.

AddPoison(mobile, poisonname, amount);
Use this function, passing the mobile you want to be poisoned,
the name of the poison in poisons.cfg to apply, and for how many seconds it should
last. If NoEnd is specified for a poison in poisons.cfg then amount will only 
mean how much curing it takes.

CurePoison(mobile, amount)
Use this function to cure poisons on the mobile.
If one poisons is completely cured, and amount is not used up, it will begin
curing the next poison on the list. Note that this function will NOT cure
any poisons that have NoCure 1 in the config.

CureSpecific(mobile, poisonname, amount)
For ones set to NoCure 1 you will need this function to specifically cure it.
Amount is how much you want to cure it. Pass -1 for amount if you want to 
totally cure it.

GetScript(mobile) 
This is a special function for the include file to make the other functions work.
It reads in a cprop called PoisonPID on the mobile to find the poison watcher script.
If the mobile doesnt have the poison watcher running on it (an NPC) then it will
start it up on that mobile at this point. If you change the package's name from poisons
to something else, you will need to adjust the start_script line here.

cfginfo(poisonname)
This is a function used by poisons.inc to find poison types, and the poison watcher
to know how to manage poisons when they are added and removed.


-=[  History  ]=----------------------------------------------


-=[  August-16-2001 Version .2 ]=-------------------------------------

Changes: 
Most of the curing methods rewritten.
All of the actual curing is now piped through Cure_Specific() in the
poison watcher.

-=[ August-18-2001 Version .3 ]=-------------------------------------

Changes:
ListPoisons(mobile, type) changed to
ListPoisonsByType(mobile,type)

Additions:
GetAllpoisons(mobile)

Bug Fixes: 
None

-=[ September-9-2001 Version .4 ]=---------------------------------------

Bug Fixes:
Bug fixed for log off scripts. Passes mobile as an offline reference.



-=[ September-9-2001 Version .5 ]=---------------------------------------

Bug Fixes:
KillPoison() was outdated. It was running cure scripts.
This was missed when everything was changed to Cure_Specific() in .2
It has now been moved there, so CureScripts wont run on logout, only
the logout script will be run at this time.

-=[ November-11-2001 Version .6 ]=---------------------------------------

Changes: 
When someone logs on and off, it sets a cprop so the poison
watcher knows when to stop. This will reduce the load it creates when
checking if a mobile is still online. 

Note: mobile.ip does not go away until the time logofftest returns has expired.

-=[ November-11-2001 Version .7 ]=---------------------------------------

General Cleanup:
Cleaned up a few lines here and there. Also tossed in a common cold virus.

-=[ December-21-2001 version .8 ]=---------------------------------------

General Cleanup:
The struct code was cleaned up. It will take fewer steps to set up and assign 
a struct. Fixed capitalization of some function names.

Changed:
All but the four mainstream poison scripts have been removed and placed as optional
scripts.

Notes:
In the next release, I plan to put in a kludge for poison resistance.

-=[ March-29-2002 version 1.0  ]=---------------------------------------

Bug Fixes: 
There was a hard to reproduce bug where on startup or shut down the poison watcher 
would get an event to cure/poison etc. and miss it. This has been fixed by making the poison 
watcher run critical when it starts and stops on a mobile.

Changes:
The poison watcher will now only run if the mobile is poisoned and online.

-=[ June-19-2002 Version 1.2 ]=-----------------------------------------

Changes: 
Changed the ShouldRun() function to check for
Events_Waiting() which will ensure no events are ever lost.

-=[ December-09-2002 Version 094 0.1 ]=---------------------------------

Updated:
  Included basic poison scripts made to work with core 094.
  Zip file changed to have 094 in it, and starting version
  counting over.
