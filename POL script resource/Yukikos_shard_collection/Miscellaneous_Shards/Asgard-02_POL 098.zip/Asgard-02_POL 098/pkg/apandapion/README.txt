This entire directory expects to be pkg\apandapion

pkg.cfg: package configuration file
ai_killpcs_harbinger.src: normal archer ai with a special ability for the harbinger of frost
ai_killpcs_servitor.src: normal monster ai with a special ability to break paralysis
ai_killpcs_snowhappy.src: smart caster ai, but casts snowstorm occasionally
ai_sniper.src: archer ai with a predisposition for *long* ranges
closedistance_servitor.inc: the servitor ai includes this to break paralysis
closedistance_sniper.inc: the sniper ai includes this to keep at long range
crazy_summoner.src: the ai for the "unstable rift" monster.
fightmode_harbinger.inc: the harbinger ai includes this to summon shrikes
npcdesc.cfg: the Circle of Winter creature stats.
pkg.cfg: duh.
readme.txt: this file