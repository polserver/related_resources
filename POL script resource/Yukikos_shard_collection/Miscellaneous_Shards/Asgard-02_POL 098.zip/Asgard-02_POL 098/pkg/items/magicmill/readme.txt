Magic Mill Ver 0.60 Read Me

Overview
-----------
The magic mill is created via a textcommand .createmill. It has a lever only gms should be able to use that will pull up a command center gump. This gump allows the gm to set the values for each magic property a magic item may have. Glowing sand is rewarded based on the values. THis version is only meant as a status report and not ment for public use.

Installation
------------
Place package in pol/items or wherever. The createmill text command should be put in a text command dir somewhere if it is to work.


The Parts
----------
    MillFront - When clicked fires off the engine, magicgrinding.src
    MillChest - Holds items to be ground, values saved in the control gump are     stored on chest as CProps.
    MillSwitch- When used fires off GM Control gump.
    MillBack - no functionality other then animations.
    Mill Table - Holds MillChest up, thats about it.


How it Works
--------------

Creation:
When mill is created two things happen, one, it sets serial numbers as CProps on other parts so it can talk to itself. Two, it sets up the statusarray[] with default values. The statusarray is then ready to hold all the data saved by the GM Control Gump.

Burning Magic Items:
Players put stuff into the chest, then click mill front to fry items. Mill front talks to the chest, looks in chst, fires off some overzealous security (MUST FIX THIS) on the items. It then sends back everything it doesnt want or things that are owned. It then sends all remaining items to the frying process. It runs each item through an identification process and grabs values for each property from the data stored on its chest. The items are then eaten.

Test Versions Only:
A result gump is sent before the chest does the burn process. this gump really needs work.


Known Bugs:

Invisibilty items may or may not work.
No Id functions to deal with player made wands.
I think Icy/Fire items will work now - which means they probaly wont.
Glowing Sand itemtype and color not setable via GM COntrol Gump - yet.
Spam when burning a lot of invalid items.
Invalid items CURRENTLY GET NUKED IF MAGIC AND IF SYSTEM DOENST KNOW WHAT THEY ARE, I must fix this ASAP.
