===================================
  Character Profile Packet Hook
  Written By Racalac
===================================

  1) Requirements
  2) How to Install
  3) Thanks To...

===================================
    Requirements
===================================
  To use these scripts, you will need the following:
    A working and installed copy of POL v.096 or newer

===================================
    How To Install
===================================
  1) Extract the zip to somewhere in your pkg directory in POL
  2) Making sure pkg.cfg has Enabled set to 1.
  3) Compile the package with eCompile.
  4) Start POL and begin using the character profile on the paperdoll!!

===================================
    Thanks To...
===================================
  Thanks to the POL dev team for continually developing the best 
    Ultima Online server emulator around.
