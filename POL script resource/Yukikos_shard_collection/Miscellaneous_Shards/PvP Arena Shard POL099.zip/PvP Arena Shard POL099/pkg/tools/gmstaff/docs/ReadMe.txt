/////////////////////////////////////////////
//
// GMstaff pkg - ver 0.36
//
/////////////////////////////////////////////
//
// Created : 15 dec 2001
// Updated : 13 feb 2003
// Author  : dougall
// Contact : dougalloogle@yahoo.com
// Requires: Gumps pkg (2.1)
//
/////////////////////////////////////////////
//
// POL094 Distro
// =============
// This package is NOT stand alone, it is
// scripted for the POL094 distro, some 
// features will not work on non-distro 
// shards!
//
// Here are the pkgs/features required
// for it to function fully:
//   - gumps pkg ( REQUIRED )
//   - spawnregion pkg
//   - spawnpoint pkg
//   - gmtools pkg
//   - guildstones pkg
//   - merchant nodes system
//   - + many distro textcommands....
//
// However, feel free to alter/use any of the 
// code from this pkg for your own nefarious
// scripting requirements!
//
/////////////////////////////////////////////
// Thanks
// ======
//
//  - Big thanks to all pol community especially
//  Syz and all dev & distro team members.
//
//  - Thanks also to Dark~Haven, Thantos and djteknix
//  for reporting errors/fixes.
//
//  - Credit where it's due, this pks is in places 
//  just a pretty front end to alot of other people's
//  (ie mostly distro team's ) work.....
//
//               Big up !
//
/////////////////////////////////////////////
//
// Installation (POL094 distro)
// ============================
//
// 1. Place Package in pkg/tools/gmstaff
//    (ie Unzip to pkg/tools )
// 2. Ecompile all in pkg
// 3. Enable package in pkg.cfg
//
// Using the GMStaff
// =================
// 1. In UOClient type ".create gmstaff"
// 2. Double Click the gmstaff and use the gump!
//
///////////////////////////////////////////
//
// P.S. please email me any bugs......
//   (why work on them when you can get someone
//   else to do it!)
//
