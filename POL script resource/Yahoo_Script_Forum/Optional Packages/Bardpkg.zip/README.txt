Installation.
-------------

1. extract to pkg\skills\
2. disable the default musicianship pkg.
3. recompile


Info.
-----

Theres total of 9 songs.

Group Reflect, Group Regeneration, Group Sight, Invigorate, Mezmerise, Rejuvenate, "Just Play"
Resurrect and Group Resurrect.

When an instrument is used it opens a gump of the songs. This pkg might need some work before it works
completely.



Lucious 6/24/03
gm_lucious@leavarius.com
icq: 17702919

I have used many of other peoples scripts as template and alas i cant remember which ones anymore
but nevertheless credits for you all.