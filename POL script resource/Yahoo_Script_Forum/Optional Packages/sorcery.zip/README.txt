Installation.
-------------

1. extract to pkg\skills\
2. append the inscription.src to yours (the ones commented for sorcery)


Info.
-----

There is total of 11 spells, id suggest going trough them all and figure good reg usage i never did :)


Lucious 6/24/03
gm_lucious@leavarius.com
icq: 17702919