Ethereal Mount Awards
Version 1
Blahgod
blahgod@thehellclan.com


Files and paths

pol\pkg\items\ethereal\ctrlReg.src
pol\pkg\items\ethereal\etherealmount.src
pol\pkg\items\ethereal\itemdesc.cfg
pol\pkg\items\ethereal\pkg.cfg
pol\config\npcdesc.cfg 		//***append these to your current cfg***
pol\scripts\misc\chrdeath.src
pol\scripts\dblclickself.src
pol\scripts\ai\tamed.src

compile and enjoy!

-BG