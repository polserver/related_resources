Bank.inc 
Austin Heilman
http://www.tsse.net

This is an include designed to help make storage areas easier to use.
To install, place in your pol/scripts/include directory.

The functions inside of bank.inc are commented with headers explaining
how to use them.

This include requires POL 095